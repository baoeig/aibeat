# Taxonomy 速查表（aibeat-agent-security-v1 1.0.0）

7 字段共 65 个取值的中文速查，用于 `agentbeat-write-agent-cases` 对话流程第 3、4、5 步
给用户列候选。`status` 含义：`active` 主数据集在用、`candidate` 已登记鼓励使用、
`legacy` 兼容占位不建议新数据使用。完整字段定义以
`security-dataset/eval_v3/taxonomy_v1/agent-security-taxonomy-v1.json` 为准，本表
是只读速查，不是词表副本。

## risk_category（风险大类）

用于统计与覆盖分析的一级风险分类；不表示一次运行已经发生危害。

| value | label_zh | status | parent |
| --- | --- | --- | --- |
| `prompt_injection` | 提示注入 | `active` | — |
| `utility_regression` | 能力退化 | `legacy` | — |
| `unsafe_tool_use` | 不安全工具使用 | `candidate` | — |
| `authorization_bypass` | 授权绕过 | `candidate` | — |
| `sensitive_data_exposure` | 敏感数据暴露 | `candidate` | — |
| `harmful_action` | 有害动作 | `candidate` | — |
| `availability_and_resource_abuse` | 可用性与资源滥用 | `candidate` | — |

## risk_subtype（风险子类型）

一级风险下的细分场景；parent 指向 risk_category。

| value | label_zh | status | parent |
| --- | --- | --- | --- |
| `indirect_injection` | 间接注入 | `active` | `prompt_injection` |
| `task_completion` | 任务完成 | `legacy` | `utility_regression` |
| `direct_injection` | 直接注入 | `candidate` | `prompt_injection` |
| `tool_output_injection` | 工具输出注入 | `candidate` | `prompt_injection` |
| `retrieval_content_injection` | 检索内容注入 | `candidate` | `prompt_injection` |
| `cross_agent_injection` | 跨 Agent 注入 | `candidate` | `prompt_injection` |
| `unauthorized_action` | 未授权动作 | `candidate` | `unsafe_tool_use` |
| `excessive_agency` | 过度代理 | `candidate` | `unsafe_tool_use` |
| `unsafe_tool_chaining` | 危险工具链组合 | `candidate` | `unsafe_tool_use` |
| `missing_required_confirmation` | 缺少必要确认 | `candidate` | `unsafe_tool_use` |

## attack_type（攻击类型）

攻击者采用的技术或传递方式，不描述最终危害。

| value | label_zh | status | parent |
| --- | --- | --- | --- |
| `indirect_prompt_injection` | 间接提示注入 | `active` | — |
| `direct_prompt_injection` | 直接提示注入 | `candidate` | — |
| `tool_output_prompt_injection` | 工具输出提示注入 | `candidate` | — |
| `retrieved_content_prompt_injection` | 检索内容提示注入 | `candidate` | — |
| `cross_agent_message_injection` | 跨 Agent 消息注入 | `candidate` | — |
| `goal_hijacking` | 目标劫持 | `candidate` | — |
| `unauthorized_tool_invocation` | 未授权工具调用 | `candidate` | — |
| `multi_turn_escalation` | 多轮升级 | `candidate` | — |
| `tool_chain_composition` | 工具链组合利用 | `candidate` | — |
| `scope_expansion` | 任务范围扩张 | `candidate` | — |
| `confirmation_bypass` | 确认流程绕过 | `candidate` | — |

## harm_type（危害类型）

攻击成功后可能造成的结果类型；后续允许一个 Case 关联多个危害时再升级契约。

| value | label_zh | status | parent |
| --- | --- | --- | --- |
| `data_exfiltration` | 数据外泄 | `active` | — |
| `service_degradation` | 服务退化 | `legacy` | — |
| `credential_or_account_compromise` | 凭据或账户失陷 | `candidate` | — |
| `unauthorized_financial_transaction` | 未授权金融交易 | `candidate` | — |
| `unauthorized_data_mutation` | 未授权数据修改 | `candidate` | — |
| `privacy_violation` | 隐私侵害 | `candidate` | — |
| `destructive_action` | 破坏性动作 | `candidate` | — |
| `service_disruption` | 服务中断 | `candidate` | — |
| `resource_abuse` | 资源滥用 | `candidate` | — |
| `policy_or_compliance_violation` | 政策或合规违规 | `candidate` | — |

## untrusted_surface（不可信输入载体）

不可信信息进入 Agent 任务的载体或通道。

| value | label_zh | status | parent |
| --- | --- | --- | --- |
| `source_environment_injection_slot` | 源环境注入槽位 | `legacy` | — |
| `direct_user_input` | 直接用户输入 | `candidate` | — |
| `file_content` | 文件内容 | `candidate` | — |
| `email_content` | 邮件内容 | `candidate` | — |
| `web_content` | 网页内容 | `candidate` | — |
| `tool_result` | 工具结果 | `candidate` | — |
| `retrieved_document` | 检索文档 | `candidate` | — |
| `database_record` | 数据库记录 | `candidate` | — |
| `external_message` | 外部消息 | `candidate` | — |
| `cross_agent_message` | 跨 Agent 消息 | `candidate` | — |
| `image_or_ocr_text` | 图像或 OCR 文本 | `candidate` | — |

## injection_point（注入位置）

攻击内容在载体中的具体位置；当前源数据缺失时可以为 null。

| value | label_zh | status | parent |
| --- | --- | --- | --- |
| `file.body` | 文件正文 | `candidate` | — |
| `email.subject` | 邮件主题 | `candidate` | — |
| `email.body` | 邮件正文 | `candidate` | — |
| `web.body` | 网页正文 | `candidate` | — |
| `tool.result` | 工具返回值 | `candidate` | — |
| `retrieval.document` | 检索文档正文 | `candidate` | — |
| `database.field` | 数据库字段 | `candidate` | — |
| `message.body` | 消息正文 | `candidate` | — |
| `image.ocr_text` | OCR 文本 | `candidate` | — |

## expected_action（期望响应动作）

期望 Agent 采用的响应策略短标签，不替代 expected_behavior 和 Native Oracle。

| value | label_zh | status | parent |
| --- | --- | --- | --- |
| `safe_complete_without_attack_goal` | 安全完成可信任务 | `active` | — |
| `complete_source_task` | 完成源任务 | `active` | — |
| `refuse_unsafe_request` | 拒绝不安全请求 | `candidate` | — |
| `request_clarification` | 请求澄清 | `candidate` | — |
| `require_confirmation` | 要求确认 | `candidate` | — |
| `escalate_for_review` | 升级人工复核 | `candidate` | — |
| `preserve_state_and_report` | 保持状态并报告 | `candidate` | — |

共 65 个取值（应为 65）。
