#!/usr/bin/env python3
"""Pack authored agent-case-only-v1 JSONL into the published dataset directory layout.

This script ships with the agentbeat-write-agent-cases Skill. It reads schema and
taxonomy files from the adjacent ``references/`` directory, so the unzipped Skill
folder can pack Cases without cloning the AI Beat repository.

It does not run evaluations, does not upload anything, and never marks a pack as
an official benchmark.
"""

from __future__ import annotations

import argparse
import gzip
import hashlib
import io
import json
import os
import re
import tarfile
from collections import Counter
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence

from jsonschema import Draft202012Validator, ValidationError

SKILL_ROOT = Path(__file__).resolve().parent.parent
REFERENCES = SKILL_ROOT / "references"
CASE_SCHEMA = REFERENCES / "agent-case-only-v1.schema.json"
TAXONOMY = REFERENCES / "agent-security-taxonomy-v1.json"
TAXONOMY_SCHEMA = REFERENCES / "agent-security-taxonomy-v1.schema.json"
CASES_NAME = "agent-cases.jsonl"
CASE_SCHEMA_NAME = "case.schema.json"
TAXONOMY_NAME = "taxonomy.json"
TAXONOMY_SCHEMA_NAME = "taxonomy.schema.json"
VALIDATION_NAME = "validation-report.json"
BUILDER_VERSION = "1.0.0"
SELECTION_VERSION = "1.0.0"
FORBIDDEN_MARKERS = ("/data/mhc/", "/home/", "/tmp/", "file://", "sk-", "AKIA")
DATASET_ID_RE = re.compile(r"^[a-z][a-z0-9-]{1,96}$")
PACKAGE_FILES = (
    CASES_NAME,
    CASE_SCHEMA_NAME,
    "manifest.json",
    TAXONOMY_NAME,
    TAXONOMY_SCHEMA_NAME,
    VALIDATION_NAME,
)
DATASET_FILES = ("README.md",) + tuple(f"package/{name}" for name in PACKAGE_FILES)
FIELDS = (
    "risk_category",
    "risk_subtype",
    "attack_type",
    "harm_type",
    "untrusted_surface",
    "injection_point",
    "expected_action",
)
DEFAULT_RELEASE_BLOCKERS = (
    "authored_pack_not_for_scoring",
    "example_cases_are_illustrative",
    "environment_profile_not_included",
)


class PackError(ValueError):
    """Raised when authored Cases cannot be turned into a dataset pack."""


def _sha256(payload: bytes) -> str:
    return hashlib.sha256(payload).hexdigest()


def _canonical_line(document: Mapping[str, Any]) -> bytes:
    return (json.dumps(document, ensure_ascii=False, sort_keys=True, separators=(",", ":")) + "\n").encode()


def load_taxonomy(path: Path = TAXONOMY, schema_path: Path = TAXONOMY_SCHEMA) -> dict[str, Any]:
    taxonomy = json.loads(path.read_text(encoding="utf-8"))
    schema = json.loads(schema_path.read_text(encoding="utf-8"))
    Draft202012Validator(schema).validate(taxonomy)
    categories = {item["value"] for item in taxonomy["fields"]["risk_category"]["values"]}
    for field in FIELDS:
        values = taxonomy["fields"][field]["values"]
        identifiers = [item["value"] for item in values]
        if len(identifiers) != len(set(identifiers)):
            raise PackError(f"taxonomy_duplicate_value:{field}")
        if field == "risk_subtype":
            for item in values:
                if item.get("parent") not in categories:
                    raise PackError(f"taxonomy_parent_unknown:{item['value']}")
    return taxonomy


def summarize_cases(
    cases: Iterable[Mapping[str, Any]],
    taxonomy: Mapping[str, Any],
) -> dict[str, Any]:
    rows = list(cases)
    unknown: dict[str, dict[str, int]] = {}
    legacy: dict[str, dict[str, int]] = {}
    for field in FIELDS:
        definitions = {
            item["value"]: item["status"]
            for item in taxonomy["fields"][field]["values"]
        }
        counts = Counter(row.get(field) for row in rows if row.get(field) is not None)
        missing = {value: count for value, count in sorted(counts.items()) if value not in definitions}
        old = {
            value: count
            for value, count in sorted(counts.items())
            if definitions.get(value) in {"legacy", "deprecated"}
        }
        if missing:
            unknown[field] = missing
        if old:
            legacy[field] = old
    return {
        "case_count": len(rows),
        "audited_fields": list(FIELDS),
        "unknown_values": unknown,
        "legacy_values": legacy,
    }


def load_jsonl(path: Path) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for index, line in enumerate(path.read_text(encoding="utf-8").splitlines(), start=1):
        if not line.strip():
            continue
        try:
            row = json.loads(line)
        except json.JSONDecodeError as exc:
            raise PackError(f"jsonl_invalid:{path.name}:{index}:{exc.msg}") from exc
        if not isinstance(row, dict):
            raise PackError(f"jsonl_not_object:{path.name}:{index}")
        rows.append(row)
    if not rows:
        raise PackError("jsonl_empty")
    return rows


def _scan_forbidden(text: str, *, where: str) -> None:
    for marker in FORBIDDEN_MARKERS:
        if marker in text:
            raise PackError(f"forbidden_content:{where}:{marker}")


def _validate_cases(cases: Sequence[Mapping[str, Any]], taxonomy: Mapping[str, Any]) -> None:
    schema = json.loads(CASE_SCHEMA.read_text(encoding="utf-8"))
    validator = Draft202012Validator(schema)
    required = list(schema["required"])
    seen_ids: set[str] = set()
    seen_prompts: set[str] = set()
    definitions = {
        field: {item["value"]: item for item in taxonomy["fields"][field]["values"]}
        for field in FIELDS
    }
    parents = {
        item["value"]: item.get("parent")
        for item in taxonomy["fields"]["risk_subtype"]["values"]
    }
    for case in cases:
        try:
            validator.validate(case)
        except ValidationError as exc:
            raise PackError(
                f"case_schema_invalid:{case.get('case_id', '?')}:{exc.message}"
            ) from exc
        extra = sorted(set(case) - set(required))
        if extra:
            raise PackError(f"extra_fields:{case.get('case_id', '?')}:{extra}")
        for banned in ("tools", "files", "runtime", "environment"):
            if banned in case:
                raise PackError(f"execution_field_not_allowed:{banned}")
        case_id = case["case_id"]
        if case_id in seen_ids:
            raise PackError(f"duplicate_case_id:{case_id}")
        seen_ids.add(case_id)
        prompt_key = " ".join(str(case["prompt"]).casefold().split())
        if prompt_key in seen_prompts:
            raise PackError(f"duplicate_prompt:{case_id}")
        seen_prompts.add(prompt_key)
        _scan_forbidden(json.dumps(case, ensure_ascii=False), where=case_id)
        category = case["risk_category"]
        subtype = case["risk_subtype"]
        if subtype in parents and parents[subtype] not in {None, category}:
            raise PackError(
                f"subtype_parent_mismatch:{case_id}:{subtype}:expected {parents[subtype]} got {category}"
            )
        for field in FIELDS:
            value = case.get(field)
            if value is None:
                continue
            if value not in definitions[field]:
                raise PackError(f"unknown_taxonomy_value:{case_id}:{field}:{value}")


def _case_counts(cases: Sequence[Mapping[str, Any]]) -> dict[str, dict[str, int]]:
    return {
        field: dict(sorted(Counter(case[field] for case in cases).items()))
        for field in (
            "sample_role",
            "risk_category",
            "risk_subtype",
            "severity",
            "observation_tier",
        )
    }


def write_package_files(
    *,
    cases: Sequence[Mapping[str, Any]],
    output_package_dir: Path,
    dataset_id: str,
    dataset_name: str,
    dataset_version: str,
    status: str,
    selection_method: str,
    by_source: Mapping[str, int],
    release_blockers: Sequence[str] = DEFAULT_RELEASE_BLOCKERS,
    migration_status: str = "not_applicable_authored_pack",
) -> dict[str, Any]:
    if not DATASET_ID_RE.match(dataset_id):
        raise PackError(f"dataset_id_invalid:{dataset_id}")
    if not dataset_name.strip() or not dataset_version.strip():
        raise PackError("dataset_identity_blank")
    taxonomy = load_taxonomy(TAXONOMY, TAXONOMY_SCHEMA)
    _validate_cases(cases, taxonomy)
    schema_bytes = CASE_SCHEMA.read_bytes()
    schema = json.loads(schema_bytes)
    case_bytes = b"".join(_canonical_line(case) for case in cases)
    taxonomy_audit = summarize_cases(cases, taxonomy)
    if taxonomy_audit["unknown_values"]:
        raise PackError(f"unknown_taxonomy_values:{taxonomy_audit['unknown_values']}")
    counts = _case_counts(cases)
    manifest = {
        "schema_version": "case-dataset-manifest-v1",
        "dataset_id": dataset_id,
        "dataset_name": dataset_name,
        "dataset_version": dataset_version,
        "status": status,
        "builder_version": BUILDER_VERSION,
        "selection": {
            "selection_version": SELECTION_VERSION,
            "method": selection_method,
            "random_sampling": False,
        },
        "cases": {
            "ref": CASES_NAME,
            "count": len(cases),
            "byte_len": len(case_bytes),
            "sha256": _sha256(case_bytes),
            "by_source": dict(by_source),
            "by_sample_role": counts["sample_role"],
            "by_risk_category": counts["risk_category"],
            "by_risk_subtype": counts["risk_subtype"],
            "by_severity": counts["severity"],
            "by_observation_tier": counts["observation_tier"],
        },
        "case_schema": {
            "ref": CASE_SCHEMA_NAME,
            "schema_version": "agent-case-only-v1",
            "sha256": _sha256(schema_bytes),
            "top_level_fields": list(schema["required"]),
        },
        "taxonomy": {
            "taxonomy_id": taxonomy["taxonomy_id"],
            "schema_version": taxonomy["schema_version"],
            "taxonomy_version": taxonomy["taxonomy_version"],
            "status": taxonomy["status"],
            "enforcement": taxonomy["enforcement"],
            "ref": TAXONOMY_NAME,
            "sha256": _sha256(TAXONOMY.read_bytes()),
            "schema_ref": TAXONOMY_SCHEMA_NAME,
            "schema_sha256": _sha256(TAXONOMY_SCHEMA.read_bytes()),
            "vocabulary": taxonomy["fields"],
            "audit": taxonomy_audit,
            "migration_status": migration_status,
        },
        "publication": {
            "official_benchmark_eligible": False,
            "score_scope": "not_for_scoring",
            "release_blockers": list(release_blockers),
        },
        "projection": {
            "execution_self_contained": False,
            "environment_resolution": "external_run_spec",
            "excluded_execution_fields": [
                "environment", "runtime", "tools", "fixture", "fixture_ref",
                "capability", "native_oracle", "integrity", "lifecycle", "lineage",
            ],
        },
    }
    validation_report = {
        "schema_version": "case-dataset-validation-report-v1",
        "dataset_id": dataset_id,
        "dataset_version": dataset_version,
        "status": "passed",
        "model_calls": 0,
        "checks": {
            "case_schema_valid": len(cases),
            "unique_case_id": len(cases),
            "single_risk_category": len(counts["risk_category"]) == 1,
            "failures": 0,
        },
        "release_blockers": list(manifest["publication"]["release_blockers"]),
        "warnings": {
            "legacy_values": taxonomy_audit.get("legacy_values") or {},
        },
    }
    validation_bytes = (
        json.dumps(validation_report, ensure_ascii=False, sort_keys=True, indent=2) + "\n"
    ).encode("utf-8")
    manifest["validation"] = {
        "ref": VALIDATION_NAME,
        "sha256": _sha256(validation_bytes),
    }
    output_package_dir.mkdir(parents=True, exist_ok=True)
    (output_package_dir / CASES_NAME).write_bytes(case_bytes)
    (output_package_dir / CASE_SCHEMA_NAME).write_bytes(schema_bytes)
    (output_package_dir / TAXONOMY_NAME).write_bytes(TAXONOMY.read_bytes())
    (output_package_dir / TAXONOMY_SCHEMA_NAME).write_bytes(TAXONOMY_SCHEMA.read_bytes())
    (output_package_dir / VALIDATION_NAME).write_bytes(validation_bytes)
    (output_package_dir / "manifest.json").write_text(
        json.dumps(manifest, ensure_ascii=False, sort_keys=True, indent=2) + "\n",
        encoding="utf-8",
    )
    return manifest


def render_readme(
    *,
    dataset_name: str,
    dataset_id: str,
    dataset_version: str,
    case_count: int,
) -> str:
    return (
        f"# {dataset_name}\n\n"
        f"- Dataset name：`{dataset_name}`\n"
        f"- Dataset ID：`{dataset_id}`\n"
        f"- Dataset version：`{dataset_version}`\n"
        f"- Case count：`{case_count}`\n"
        f"- Taxonomy ID：`aibeat-agent-security-v1`\n"
        f"- Taxonomy version：`1.0.0`\n\n"
        "## 这是对话写成的题目包，不是官方榜\n\n"
        "每条 Case 只有 `agent-case-only-v1` 的 21 个顶层字段，用来描述要测什么。"
        "包里**没有** `tools` / `files` / `runtime` / `environment`。"
        "`official_benchmark_eligible` 固定为 false，不能当官方分数引用。\n\n"
        "## 目录\n\n"
        "- `README.md`（本文件）\n"
        "- `package/agent-cases.jsonl`\n"
        "- `package/case.schema.json`\n"
        "- `package/manifest.json`\n"
        "- `package/taxonomy.json`（canonical 全量词表，65 个取值）\n"
        "- `package/taxonomy.schema.json`\n"
        "- `package/validation-report.json`\n\n"
        "## 下一步\n\n"
        "要把这个包真正跑起来，还需要独立的 Target 与 Environment / RunSpec，"
        "那不是本打包器做的事。本目录只保证题目契约和发布包结构对齐。\n"
    )


def write_dataset_directory(
    *,
    cases: Sequence[Mapping[str, Any]],
    output_dir: Path,
    dataset_id: str,
    dataset_name: str,
    dataset_version: str,
    status: str = "draft",
    selection_method: str = "authored_conversation",
    by_source: Mapping[str, int] | None = None,
    readme_text: str | None = None,
    release_blockers: Sequence[str] = DEFAULT_RELEASE_BLOCKERS,
    migration_status: str = "not_applicable_authored_pack",
) -> dict[str, Any]:
    source_counts = dict(by_source) if by_source is not None else {"authored": len(cases)}
    manifest = write_package_files(
        cases=cases,
        output_package_dir=output_dir / "package",
        dataset_id=dataset_id,
        dataset_name=dataset_name,
        dataset_version=dataset_version,
        status=status,
        selection_method=selection_method,
        by_source=source_counts,
        release_blockers=release_blockers,
        migration_status=migration_status,
    )
    text = readme_text or render_readme(
        dataset_name=dataset_name,
        dataset_id=dataset_id,
        dataset_version=dataset_version,
        case_count=len(cases),
    )
    _scan_forbidden(text, where="README.md")
    (output_dir / "README.md").write_text(text, encoding="utf-8")
    return manifest


def write_tar_gz(dataset_dir: Path, tar_path: Path) -> bytes:
    members: list[tuple[str, bytes]] = []
    readme = dataset_dir / "README.md"
    if not readme.is_file():
        raise PackError("readme_missing")
    members.append(("README.md", readme.read_bytes()))
    package = dataset_dir / "package"
    for name in PACKAGE_FILES:
        path = package / name
        if not path.is_file():
            raise PackError(f"package_file_missing:{name}")
        payload = path.read_bytes()
        _scan_forbidden(payload.decode("utf-8", errors="replace"), where=name)
        members.append((f"package/{name}", payload))
    buffer = io.BytesIO()
    with gzip.GzipFile(filename="", mode="wb", fileobj=buffer, mtime=0, compresslevel=9) as compressed:
        with tarfile.open(fileobj=compressed, mode="w", format=tarfile.USTAR_FORMAT) as archive:
            directory = tarfile.TarInfo("package/")
            directory.type = tarfile.DIRTYPE
            directory.mode = 0o755
            directory.mtime = directory.uid = directory.gid = 0
            directory.uname = directory.gname = ""
            archive.addfile(directory)
            for archive_name, payload in members:
                info = tarfile.TarInfo(archive_name)
                info.size = len(payload)
                info.mode = 0o644
                info.mtime = info.uid = info.gid = 0
                info.uname = info.gname = ""
                archive.addfile(info, io.BytesIO(payload))
    payload = buffer.getvalue()
    tar_path.parent.mkdir(parents=True, exist_ok=True)
    tmp = tar_path.with_name(f".{tar_path.name}.tmp")
    try:
        tmp.write_bytes(payload)
        os.replace(tmp, tar_path)
        os.chmod(tar_path, 0o644)
    finally:
        if tmp.exists():
            tmp.unlink()
    return payload


def pack_jsonl(
    *,
    cases_path: Path,
    output_dir: Path,
    dataset_id: str,
    dataset_name: str,
    dataset_version: str,
    write_tar: bool = False,
) -> dict[str, Any]:
    cases = load_jsonl(cases_path)
    manifest = write_dataset_directory(
        cases=cases,
        output_dir=output_dir,
        dataset_id=dataset_id,
        dataset_name=dataset_name,
        dataset_version=dataset_version,
    )
    receipt: dict[str, Any] = {
        "output_dir": str(output_dir),
        "files": list(DATASET_FILES),
        "case_count": manifest["cases"]["count"],
        "dataset_id": dataset_id,
        "dataset_version": dataset_version,
        "official_benchmark_eligible": False,
        "legacy_values": manifest["taxonomy"]["audit"].get("legacy_values") or {},
    }
    if write_tar:
        tar_path = output_dir.parent / f"{output_dir.name}.tar.gz"
        payload = write_tar_gz(output_dir, tar_path)
        receipt["tar"] = {
            "path": str(tar_path),
            "bytes": len(payload),
            "sha256": _sha256(payload),
        }
    return receipt


def main(argv: Iterable[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description="把 agent-case-only-v1 JSONL 打成与发布包同结构的本地数据集目录。不执行评测、不上传。",
    )
    parser.add_argument("--cases", type=Path, required=True, help="一行一条 Case 的 JSONL")
    parser.add_argument("--output-dir", type=Path, required=True, help="输出目录，将写入 README.md 与 package/")
    parser.add_argument("--dataset-id", required=True, help="小写字母开头的数据集 ID，例如 my-agent-cases")
    parser.add_argument("--dataset-name", required=True, help="给人看的数据集名称")
    parser.add_argument("--dataset-version", default="0.1.0")
    parser.add_argument("--tar", action="store_true", help="额外写出同名 tar.gz，不上传、不发布")
    args = parser.parse_args(list(argv) if argv is not None else None)
    receipt = pack_jsonl(
        cases_path=args.cases,
        output_dir=args.output_dir,
        dataset_id=args.dataset_id,
        dataset_name=args.dataset_name,
        dataset_version=args.dataset_version,
        write_tar=args.tar,
    )
    print(json.dumps(receipt, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
